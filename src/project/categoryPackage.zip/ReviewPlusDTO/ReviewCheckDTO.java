package project.categoryPackage.ReviewPlusDTO;

import lombok.Data;

@Data
public class ReviewCheckDTO {
    private String user_id;
    private int book_no;
}
