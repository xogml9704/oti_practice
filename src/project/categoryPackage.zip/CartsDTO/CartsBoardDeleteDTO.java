package project.categoryPackage.CartsDTO;

import lombok.Data;

@Data
public class CartsBoardDeleteDTO {
    private String user_id;
    private int book_no;
}
