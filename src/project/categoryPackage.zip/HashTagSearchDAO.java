package project.categoryPackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import project.categoryPackage.HashTagSerachDTO.HashTagSearchDTO;

public class HashTagSearchDAO {
    // 해시테그 페이지 검색
    public ArrayList<HashTagSearchDTO> HashTagSearch(Connection conn) {
        ArrayList<HashTagSearchDTO> hashTagSearchList = new ArrayList<HashTagSearchDTO>();
        try {
            String sql = "";
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
