package project.categoryPackage.HashTagSerachDTO;

import lombok.Data;

@Data
public class HashTagSearchDTO {
}
