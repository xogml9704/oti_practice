package project.categoryPackage.BookboardDTO;

import lombok.Data;

@Data
public class DibsDTO {
    private int book_no;
    private String user_id;
}
