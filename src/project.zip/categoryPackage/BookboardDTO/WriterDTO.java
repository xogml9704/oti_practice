package project.categoryPackage.BookboardDTO;

import lombok.Data;

@Data
public class WriterDTO {
    private String author_name;
    private String author_detail;
}
