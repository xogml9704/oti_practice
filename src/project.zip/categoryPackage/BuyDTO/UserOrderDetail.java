package project.categoryPackage.BuyDTO;

import lombok.Data;

@Data
public class UserOrderDetail {
   private int order_no;
   private int book_no;
   private int od_qty;
}