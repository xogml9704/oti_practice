package project.categoryPackage.CategoryDTO;

import lombok.Data;

@Data
public class CategoryDTO {
    private int category_no;
    private String category_name;
}