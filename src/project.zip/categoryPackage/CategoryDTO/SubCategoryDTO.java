package project.categoryPackage.CategoryDTO;

import lombok.Data;

@Data
public class SubCategoryDTO {
    private int sub_no;
    private String sub_name;
}
