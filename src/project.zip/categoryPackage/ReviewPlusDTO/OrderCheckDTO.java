package project.categoryPackage.ReviewPlusDTO;

import lombok.Data;

@Data
public class OrderCheckDTO {
    private String user_id;
    private int book_no;
}
