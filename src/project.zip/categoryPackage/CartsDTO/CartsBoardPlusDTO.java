package project.categoryPackage.CartsDTO;

import lombok.Data;

@Data
public class CartsBoardPlusDTO {
    private String user_id;
    private int book_no;
    private int cart_qty;
}
