package project.categoryPackage.CartsDTO;

import lombok.Data;

@Data
public class CartsBoardQtyDTO {
    private int cart_qty;
    private String user_id;
    private int book_no;
}
