package project.categoryPackage.CartsDTO;

import lombok.Data;

@Data
public class CartsBoardAllDeleteDTO {
    private String user_id;
}
